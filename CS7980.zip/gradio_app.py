import gradio as gr
import torch
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2 import model_zoo
from detectron2.data import MetadataCatalog, DatasetCatalog
from detectron2.data.datasets import register_coco_instances
from detectron2.utils.visualizer import Visualizer
import cv2

# Register your custom dataset
def register_custom_dataset():
    dataset_name = "custom_airplane_defects"
    
    # Check if the dataset is already registered
    if dataset_name in DatasetCatalog.list():
        
        return dataset_name
    
    json_file = "./test/_annotations.coco.json"  # Update with your COCO JSON path
    image_root = "./test"  # Update with your images directory path
    
    # Register the dataset
    register_coco_instances(dataset_name, {}, json_file, image_root)
    
    # Set the metadata
    MetadataCatalog.get(dataset_name).thing_classes = [
         "airplane", "crack", "dent", "missing-head", "paint-off", "scratch"
    ]
    return dataset_name

# Function to load the model
def load_model():
    cfg = get_cfg()
    cfg.merge_from_file(model_zoo.get_config_file("COCO-Detection/retinanet_R_50_FPN_3x.yaml"))
    cfg.MODEL.WEIGHTS = "final_model.pth"  # Update with your trained model path
    cfg.MODEL.RETINANET.NUM_CLASSES = 6  # Your custom classes
    cfg.MODEL.RETINANET.SCORE_THRESH_TEST = 0.5
    cfg.MODEL.DEVICE = "cpu"  # Use "cpu" if you don't have a GPU
    
    # Register and set the dataset
    dataset_name = register_custom_dataset()
    cfg.DATASETS.TRAIN = (dataset_name,)
    cfg.DATASETS.TEST = ()
    
    # Initialize the predictor
    predictor = DefaultPredictor(cfg)
    return predictor, cfg

# Function for inference
def predict(image):
    # Ensure the image is in the correct format
    original_image = image.copy()
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Load the model and configuration
    predictor, cfg = load_model()
    
    # Perform inference on the input image
    outputs = predictor(image)
    
    # Debugging: Print out bounding box coordinates
    boxes = outputs["instances"].pred_boxes
    print("Bounding boxes:", boxes)
    
    # Ensure bounding boxes are within the image dimensions
    for box in boxes:
        if not all(0 <= coord <= max(image.shape[:2]) for coord in box):
            print("Warning: Bounding box coordinates are outside the image dimensions!")
    
    # Visualize the prediction results on the image
    v = Visualizer(original_image[:, :, ::-1], MetadataCatalog.get(cfg.DATASETS.TRAIN[0]), scale=1.0)
    v = v.draw_instance_predictions(outputs["instances"].to("cpu"))
    
    # Return the visualized image
    return v.get_image()[:, :, ::-1]

# Set up the Gradio interface
gr.Interface(fn=predict, inputs="image", outputs="image").launch(share=True)
